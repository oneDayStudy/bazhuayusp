// to top icon
$(".page").on('scroll', function () {
if ($(".page").scrollTop()>200){  
$(".totop").fadeIn(500);  
}else{ 
$(".totop").fadeOut(500);
}
});
$(".totop").on('click', function () {  
$('.page').animate({scrollTop:0},300);  
return false;
}); 